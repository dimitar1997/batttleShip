package com.example.batttleship.services.impl;

import com.example.batttleship.currenUser.CurrentUser;
import com.example.batttleship.models.entity.Ship;
import com.example.batttleship.models.entity.User;
import com.example.batttleship.models.service.AddShipServiceModel;
import com.example.batttleship.models.view.AllShipsViewModel;
import com.example.batttleship.models.view.AnotheUserShipsViewModel;
import com.example.batttleship.models.view.CurrentUserShipsViewModel;
import com.example.batttleship.repository.ShipRepository;
import com.example.batttleship.repository.UserRepository;
import com.example.batttleship.services.ShipService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ShipServiceImpl implements ShipService {

    private final ShipRepository shipRepository;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final CurrentUser currentUser;

    public ShipServiceImpl(ShipRepository shipRepository, ModelMapper modelMapper, UserRepository userRepository, CurrentUser currentUser) {
        this.shipRepository = shipRepository;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.currentUser = currentUser;
    }

    @Override
    public void addOrder(AddShipServiceModel addShipServiceModel) {
        Ship ship = modelMapper.map(addShipServiceModel, Ship.class);
        shipRepository.save(ship);
    }

    @Override
    public List<CurrentUserShipsViewModel> findAllShipsOfCurrentUser() {
        User user = userRepository.getById(currentUser.getId());
        return shipRepository.findAllByUser(user)
                .stream().map(ship -> modelMapper.map(ship, CurrentUserShipsViewModel.class))
                .collect(Collectors.toList());

    }

    @Override
    public List<AnotheUserShipsViewModel> findAnotherUserShips() {
        long id = userRepository.count();
        if (currentUser.getId() == id){
           id-=1;
        }
        User user = userRepository.getById(id);
        return shipRepository.findAllByUser(user)
                .stream().map(ship -> modelMapper.map(ship, AnotheUserShipsViewModel.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<AllShipsViewModel> getAllShips() {
        return shipRepository.findAllByOrderByIdAndHealthPower()
                .stream().map(ship -> modelMapper.map(ship, AllShipsViewModel.class))
                .collect(Collectors.toList());
    }
}
