package com.example.batttleship.services.impl;

import com.example.batttleship.currenUser.CurrentUser;
import com.example.batttleship.models.biding.LoginBidingModel;
import com.example.batttleship.models.entity.User;
import com.example.batttleship.models.service.RegisterServiceModel;
import com.example.batttleship.models.service.UserServiceLoginModel;
import com.example.batttleship.repository.UserRepository;
import com.example.batttleship.services.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final CurrentUser currentUser;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper, CurrentUser currentUser) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.currentUser = currentUser;
    }

    @Override
    public void registerUser(RegisterServiceModel registerServiceModel) {
        User user = modelMapper
                .map(registerServiceModel, User.class);
        userRepository.save(user);
    }

    @Override
    public UserServiceLoginModel findLoginUser(LoginBidingModel loginBindingModel) {
        User user = userRepository.findByUsernameAndPassword(
                loginBindingModel.getUsername(),
                loginBindingModel.getPassword())
                .orElse(null);
        if (user == null){
            return null;
        }else {
            return modelMapper.map(user,UserServiceLoginModel.class);
        }
    }

    @Override
    public void loginUser(long id, String username) {
        currentUser.setId(id);
        currentUser.setUsername(username);
    }
}
