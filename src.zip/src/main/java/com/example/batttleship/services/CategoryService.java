package com.example.batttleship.services;

public interface CategoryService {
    void initCategories();
}
