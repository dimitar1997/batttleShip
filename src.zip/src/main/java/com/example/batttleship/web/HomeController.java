package com.example.batttleship.web;

import com.example.batttleship.currenUser.CurrentUser;
import com.example.batttleship.models.view.AllShipsViewModel;
import com.example.batttleship.models.view.AnotheUserShipsViewModel;
import com.example.batttleship.models.view.CurrentUserShipsViewModel;
import com.example.batttleship.services.ShipService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class HomeController {

    private final CurrentUser currentUser;
    private final ShipService shipService;

    public HomeController(CurrentUser currentUser, ShipService shipService) {
        this.currentUser = currentUser;
        this.shipService = shipService;
    }

    @GetMapping("/")
    public String index(Model model) {
        if (currentUser.getId() == null) {
            return "index";
        }
        List<CurrentUserShipsViewModel> currentUserShipsViewModels = shipService.findAllShipsOfCurrentUser();
        model.addAttribute("currentUserShips", currentUserShipsViewModels);
        List<AnotheUserShipsViewModel> anotheUserShipsViewModels = shipService.findAnotherUserShips();
        model.addAttribute("anotherUserShips", anotheUserShipsViewModels);
        List<AllShipsViewModel> allShipsViewModels = shipService.getAllShips();
       model.addAttribute("allships", allShipsViewModels);
        return "home";

    }

}
