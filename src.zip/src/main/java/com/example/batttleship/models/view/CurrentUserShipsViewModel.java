package com.example.batttleship.models.view;

import com.example.batttleship.models.entity.Category;
import com.example.batttleship.models.entity.User;

import java.time.LocalDate;

public class CurrentUserShipsViewModel {
    private long id;
    private String name;
    private Integer health;
    private Integer power;
    private LocalDate created;
    private Category category;
    private User user;

    public CurrentUserShipsViewModel() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getHealth() {
        return health;
    }

    public void setHealth(Integer health) {
        this.health = health;
    }

    public Integer getPower() {
        return power;
    }

    public void setPower(Integer power) {
        this.power = power;
    }

    public LocalDate getCreated() {
        return created;
    }

    public void setCreated(LocalDate created) {
        this.created = created;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
