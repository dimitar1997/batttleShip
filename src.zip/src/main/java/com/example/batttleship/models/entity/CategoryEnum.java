package com.example.batttleship.models.entity;

public enum CategoryEnum {
    BATTLE, CARGO, PATROL
}
