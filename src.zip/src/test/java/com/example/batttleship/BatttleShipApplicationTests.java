package com.example.batttleship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatttleShipApplicationTests {

    @Test
    void contextLoads() {
    }

}
